#include "BoostDef.h"

BoostDef::BoostDef(): Potion{Potion_Type::DEF_BOOST, true, 5, 'P'} {} 
