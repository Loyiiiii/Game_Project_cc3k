#ifndef BOOST_ATK_H
#define BOOST_ATK_H

#include "Potion.h"
#include "Global_Constants.h"

class BoostAtk : public Potion {
public:
    // ctor for BoostATK
    BoostAtk();
};

#endif 
