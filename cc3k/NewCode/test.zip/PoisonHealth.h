#ifndef POISON_HEALTH_H
#define POISON_HEALTH_H

#include "Potion.h"
#include "Global_Constants.h"

class PoisonHealth : public Potion {
public:
    PoisonHealth();
};

#endif 