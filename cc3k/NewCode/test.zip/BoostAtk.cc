#include "BoostAtk.h"

BoostAtk::BoostAtk(): Potion{Potion_Type::ATK_BOOST, true, 5, 'P'} {} 