#include "WoundAtk.h"

WoundAtk::WoundAtk() : Potion{ Potion_Type::WOUND_ATK, true, -5, 'P' } {} 