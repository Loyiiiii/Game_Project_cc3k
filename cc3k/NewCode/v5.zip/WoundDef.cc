#include "WoundDef.h"

WoundDef::WoundDef() : Potion{ Potion_Type::WOUND_DEF, true, -5, 'P' } {} 