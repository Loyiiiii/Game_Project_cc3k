#ifndef WOUND_ATK_H
#define WOUND_ATK_H

#include "Potion.h"
#include "Global_Constants.h"

class WoundAtk : public Potion {
public:
    WoundAtk();
};

#endif 