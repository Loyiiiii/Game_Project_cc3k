#ifndef WOUND_DEF_H
#define WOUND_DEF_H

#include "Potion.h"
#include "Global_Constants.h"

class WoundDef : public Potion {
public:
    WoundDef();
};

#endif 