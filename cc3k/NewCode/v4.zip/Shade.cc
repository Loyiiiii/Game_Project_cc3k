#include "Shade.h"

Shade::Shade() :
    PlayerCharacter{ 125, 125, 25, 25, 0, Race::SHADE, true } {} 
