#include "PoisonHealth.h"

PoisonHealth::PoisonHealth() : Potion{ Potion_Type::POISON_HEALTH, false, -10, 'P' } {} 