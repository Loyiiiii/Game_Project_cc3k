#ifndef RESTORE_HEALTH_H
#define RESTORE_HEALTH_H

#include "Potion.h"
#include "Global_Constants.h"

class RestoreHealth : public Potion {
public:
    RestoreHealth();
};

#endif 