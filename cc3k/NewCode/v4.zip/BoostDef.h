#ifndef BOOST_DEF_H
#define BOOST_DEF_H

#include "Potion.h"
#include "Global_Constants.h"

class BoostDef : public Potion {
public:
    BoostDef();
};

#endif 
