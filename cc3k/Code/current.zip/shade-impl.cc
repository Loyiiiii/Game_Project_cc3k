module Shade;

Shade::Shade(Position pos):
    PlayerCharacter(pos) {}
