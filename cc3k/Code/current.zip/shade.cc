export module Shade;

export class Shade: public PlayerCharacter {
    public:
        Shade(Position pos);
};
