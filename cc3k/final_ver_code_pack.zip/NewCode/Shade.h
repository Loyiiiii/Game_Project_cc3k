#ifndef SHADE_H
#define SHADE_H

#include "PlayerCharacter.h"
#include "Global_Constants.h"

class Shade : public PlayerCharacter {
public:
    Shade();
};

#endif
