#include "MerchantHoard.h"

MerchantHoard::MerchantHoard() : Gold{ 4, false } {} 
