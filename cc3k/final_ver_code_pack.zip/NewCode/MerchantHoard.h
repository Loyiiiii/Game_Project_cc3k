#ifndef MERCHANT_HOARD_H
#define MERCHANT_HOARD_H

#include "Gold.h"

class MerchantHoard : public Gold {
public:
    MerchantHoard();
};

#endif 
