#ifndef SMALL_GOLD_H
#define SMALL_GOLD_H

#include "Gold.h"

class SmallGold : public Gold {
public:
    SmallGold();
};

#endif 
