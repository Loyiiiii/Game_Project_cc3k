#include "RestoreHealth.h"

RestoreHealth::RestoreHealth() : Potion{ Potion_Type::HEALTH_RESTORE, false, 10, 'P' } {} 
