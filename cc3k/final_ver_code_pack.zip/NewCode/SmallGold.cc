#include "SmallGold.h"

SmallGold::SmallGold() : Gold{ 1, true } {} 
