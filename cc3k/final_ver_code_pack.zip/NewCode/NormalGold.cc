#include "NormalGold.h"

NormalGold::NormalGold() : Gold{ 2, true } {} 
