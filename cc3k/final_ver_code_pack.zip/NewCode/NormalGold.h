#ifndef NORMAL_GOLD_H
#define NORMAL_GOLD_H

#include "Gold.h"

class NormalGold : public Gold {
public:
    NormalGold();
};

#endif 
